For assistance see:
http://www.picnet.com.au/picnet_table_filter.html