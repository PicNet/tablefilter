For assistance see:
http://www.picnet.com.au/picnettablefilter/